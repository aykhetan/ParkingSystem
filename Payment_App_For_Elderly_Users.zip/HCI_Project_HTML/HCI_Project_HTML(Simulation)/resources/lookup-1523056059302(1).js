(function(window, undefined) {
  var dictionary = {
    "6a6208ab-db8e-4106-b227-32597606eb17": "Make_Payment_QR_Code_Final_Authetication_Wrong_MPin",
    "b7f363c1-62a2-4917-b923-a90caa2ace56": "Receive_Money_Requesting_User_Enter_Amount_Error",
    "243e7ae2-f171-4783-9132-bd3c901a11b2": "Menu_Settings_Touch_ID",
    "f3775e3b-c241-417d-938e-e2b24eb15b26": "Receive_Money_Requesting_User_Verified",
    "20b658b4-e4f9-413b-aefa-93c0e8d365bb": "Login_Successful_Screen_Search Error",
    "1d84d33e-7065-44a3-8863-24880b12bd89": "Menu_Transaction_Details",
    "48f72e62-f6ec-4f7f-87ea-9244463a1027": "Make_Payment_QR_Code_Scanning_Successful_Cancel_Confirmation",
    "a7b158b9-a567-4185-92e3-aa88bbfd1615": "Receive_Transaction_Options",
    "d7e7d247-9ded-4f5b-ba35-34dc5755768e": "Menu_Settings_Change_MPin_Enter_Current_MPin_Mismatch",
    "114cbe3d-929d-49ca-a68a-1f922e2ca022": "Make_Payment_Merchant_Request_Done_Cancel_Confirmation",
    "a73a2358-c76e-446c-9507-4b2f576cd99e": "Make_Payment_Using_Merchant_ID_Enter_Amount_After_ID_Verification_Error",
    "709a65ef-320b-4411-a56d-876cacfdb260": "Receive_Money_Requesting_User_Enter_Amount_Cancel_Confirmation",
    "bdc2a008-68e4-442e-9fa1-48c415299726": "Receive_Money_Requesting_User_Final_Confirmation",
    "5b30c2ff-1f97-4546-8860-b61c607c9e9d": "Logout_Successful_Feedback",
    "f92f135f-2a84-4ff2-ae8a-1421f38df1bb": "Make_Payment_Using_Merchant_ID_Verified_ID",
    "1fee8e2e-aa62-47dd-b2a0-bedf714c6557": "Make_Payment_Merchant_Request_Final_Authentication_Cancel_Confirmation",
    "ea83f5eb-2e83-4337-94a1-bbfe5b7159d2": "Make_Payment_Using_Merchant_ID_Wrong_Merchant_ID",
    "2dd64e3f-66d2-4760-a8ba-feeee3ea5e17": "Menu_Settings_Face_ID_Set-Reset_Popup",
    "48fed875-7a35-4f32-9514-cf49132ad2bf": "Menu_Settings_Change_MPin_Enter_Current_MPin",
    "f2979cb9-a29d-406b-a201-5e144133999c": "Receive_Money_Requesting_User_Final_Authentication",
    "b945cffe-34a8-42e4-8e28-6f9654affa7c": "Receive_Money_Requesting_User",
    "4fd2b440-7a85-4b79-b3f8-d2ce0da66e62": "Make_Payemnt_Using_Merchant_ID_Successful_Confirmation",
    "9d15dd11-6fc4-4d0f-83a8-98da3720867b": "Receive_Money_Requesting_User_Enter_Amount_Proceed_ID_Verification",
    "65f1ed8c-20dc-4e3a-a174-d5ff1f04fd29": "Make_Payement_QR_Code_Successful",
    "2d7e48c2-9b2f-44d0-a958-984c77633c32": "Menu_Settings_Face_ID",
    "a6f82baf-7369-40d8-b4d8-28c07f18df1a": "Login_Screen_Forgot_MPin",
    "3f27f0f8-686b-4c6f-9031-c854c1fb34c0": "Menu_Settings_Change_MPin_Enter_New_MPin_Mismatch",
    "bad103ec-2ac3-4c88-aaf8-5fa8ff03f3fa": "Make_Payment_QR_Code_Final_Authentication",
    "07f93b25-ef7a-4ed5-a2cb-278809abb53c": "Make_Payment_QR_Code_Scanning_Successful_Error",
    "e7968aa2-015d-4203-9962-9a7d622e64e8": "Make_Payment_QR_Code",
    "abb777ee-d007-4b25-9227-c4daf59be854": "Login_Screen_Exit_Screen_Confirmation_Dialogue",
    "0cf817cf-65d2-4503-b172-d4977580ebbb": "Make_Payment_QR_Code_Final_Submission",
    "ee1ce50b-b553-4118-8267-e07a99dd7441": "Menu_License",
    "e17e696a-f806-4b13-ba69-94ae87633e33": "Make_Payment_Using_Merchant_ID_Enter_Amount_After_ID_Verification",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Home_Page",
    "5d9917af-72fe-4bcd-9346-ee7796832f9c": "Receive_Money_Requesting_User_Final_Submission",
    "e0947833-654b-48a7-bce0-cc44fcec2c60": "Make_Payment_QR_Code_Final_Authentication_Cancel_Confirmation",
    "9808e78c-f15d-42eb-be03-529985965b86": "Make_Payment_Using_Merchant_ID_Enter_Merchant_ID",
    "a150c1e0-b65f-4d7a-9d29-52a7e2bd52a1": "Make_Payment_Using_Merchant_ID_Final_Authentication",
    "ef3b3eb2-802d-4fa4-8c5c-a02ecc54bbd8": "Receive_Money_Requesting_User_ID_Verified_Cancel_Confirmation",
    "90c9694d-5248-46fe-b554-2b65cb201464": "Make_Payment_Merchant_Request_Final_Authentication_Worng_MPin",
    "78ba7499-3354-497d-b2ae-be6335fbdfb4": "Receive_Money_Requesting_User_Wrong_ID",
    "74c9b9f4-2efe-4fd3-b744-e03b1ef6467f": "Make_Payment_Using_Merchant_ID_Verified_ID_Cancel_Confirmation",
    "7c9e9322-f6ad-411e-a7f1-da7ba6cd7d34": "Make_Payment_QR_Code_Scanning",
    "d5f82e41-6fd2-47a8-9d04-f76e2de8cde0": "Make-Payment_Merchant_Request_Final_Authentication",
    "486ede6f-f9dd-4d7d-bda1-805287c820a6": "Menu_User_Profile",
    "47244a38-be66-46c0-88e3-4a4265f6b7c8": "Menu_Settings",
    "f85121b1-459c-4607-bd07-fb40fcdd1bd5": "Make_Payment_Using_Merchant_ID_Final_Submission_Cancel_Confirmation",
    "08fbaae1-0313-4ea4-93ad-e0827f092610": "Receive_Payement_Payment_ID_Details",
    "c8653f7f-beb4-482b-9487-8419d3193afa": "Receive_Payement_QR_Code_Details",
    "2ef08bb7-201f-4d18-8de6-6adc5d0a3980": "Make_Payment_Merchant_Request",
    "243c002a-1466-403c-81e0-9925d7004731": "Make_Payment_QR_Code_Scanning_Successful",
    "bf4860b5-8ee6-494d-a63d-573358339280": "Make_Payment_Using_Merchant_ID_Final_Authentication_Wrong_MPin",
    "7b46f200-cf6d-4f5f-8fb3-1dd3f388a75b": "Menu_Settings_Change_MPin_Enter_New_MPin",
    "dd333492-7a50-470e-8622-5661f5a072a5": "Make_Payment_Using_Merchant_ID_Final_Authentication_Cancel_Confirmation",
    "e8693fa7-426f-46bf-945b-15ade2fbee29": "App_Opened_Login_Screen",
    "1d70b40b-80a9-4aa7-a325-2dfb570b21d7": "Menu_Settings_Change_MPin_Success_Confirmation",
    "fbafd115-83dc-4bd3-828e-a9f64a006086": "App_Opened_Login_Screen_Password Mismatch",
    "e734dc67-c60c-4cd7-ba69-22548050e7b9": "Make_Payment_Merchant_Request_Done",
    "a2294bee-8242-47a4-9d05-5c65f8ec2cff": "Receive_Money_Requesting_User_Authenticaction_Cancel_Confimration",
    "a5d10755-3179-4a76-8f94-199158c1b5ad": "Send_Transaction_Options",
    "29eca499-082c-4c95-9328-056b12312246": "Make_Payment_Merchant_Request_Successful",
    "2c06eb31-15a2-421b-a4fb-4e7d7c5f3687": "Make_Payment_Using_Merchant_ID_Final_Submission",
    "0281ded4-4c6d-4d36-872c-9c33009d376f": "Make_Payment_QR_Code_Final_Submission_Cancel_Confirmation",
    "c70d6f23-e0c2-4833-945a-63942a9fcd1b": "Make_Payment_Using_Merchant_ID_Enter_Amount_Cancel_Confirmation",
    "77adaf31-f068-4844-856b-6bf1e7b62645": "Receive_Money_Requesting_User_Final_Submission_Cancel_Confirmation",
    "4563f8f4-3085-4944-980f-b6fcaed4d338": "Menu_Settings_Touch_ID_Set-Reset_Popup",
    "7fd32991-d608-497a-94dc-5718b4150b99": "Login_Successful_Screen",
    "abaf8c7b-cbe6-4b52-834e-668e58f0b8f4": "Logout_Screen_Confirmation_Dialogue",
    "298f597a-af6c-4a3e-aea5-457162482708": "Menu_About_Us",
    "2f4096f9-61b7-4601-ab85-e14d49509249": "Receive_Money_Requesting_User_Final_Authentication_Wrong_MPin",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);